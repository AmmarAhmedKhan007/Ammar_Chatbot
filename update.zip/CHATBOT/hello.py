# @app.route('/api/chatbot/GetResponse', methods=['POST'])
# def get_response():
#     # Logging request headers and body for debugging
#     app.logger.debug("Request headers: {}".format(request.headers))
#     app.logger.debug("Request body: {}".format(request.get_data(as_text=True)))

#     print('API IS WORKING')

#     try:
#         # Parse the incoming request
#         data = request.get_json()
#         if not data or 'text' not in data:
#             return jsonify({'error': 'Invalid input'}), 400

#         question = data['text']

#         # Create a chat session
#         chat_session = model.start_chat(history=[])

#         # Send the input text to the chat session
#         response = chat_session.send_message(question)

#         # Extract the response text from the response object
#         response_text = response.text  # Assuming `text` is the attribute holding the string

#         clean_response = re.sub(r'^\*\s*|\*\s*$', '', response.text)
#         clean_response = response_text.replace('*', '')
#         clean_response = clean_response.replace('\ud83d\udc4b', '👋').replace('\ud83d\ude0a', '😎')

#         return jsonify({'response': clean_response})

#     except Exception as e:
#         # Log any errors and return an appropriate response
# 		app.logger.error("Error processing request: {}".format(e))

#         return jsonify({'error': str(e)}), 500
