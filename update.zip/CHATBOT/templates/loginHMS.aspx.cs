﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Text;
using System.Web;
using System.IO;
using System.Net.Mail;
using System.Xml.Linq;

namespace pointofsale
{
    public partial class loginHMS : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                   
                }
            }
            catch (Exception ex)
            {
                
            }
        }
        
        private string GetClientIPAddress()
        {
            string ipAddress = String.Empty;

            try
            {
                ipAddress = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];

                if (string.IsNullOrEmpty(ipAddress))
                {
                    ipAddress = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            return ipAddress;
        }
        protected void InsertLog(string description, string name)
        {
           
        }
        private void ActiveInActive(string hotelid)
        {
           
        }
        protected void Login_Click(object sender, EventArgs e)
        {
        }    private void LogException(Exception ex)
        {
            
        }
       
    }
}